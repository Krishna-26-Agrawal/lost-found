import os
import re
import sqlite3
from datetime import datetime
from flask import Flask, render_template, request, redirect, url_for, flash
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.secret_key = 'super_secret_key_change_in_production'

UPLOAD_FOLDER = os.path.join('static', 'uploads')
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
DATABASE = 'lost_and_found.db'

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def get_db_connection():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with app.app_context():
        conn = get_db_connection()
        conn.execute('''
            CREATE TABLE IF NOT EXISTS items (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                report_type TEXT NOT NULL,
                category TEXT NOT NULL,
                location TEXT NOT NULL,
                description TEXT NOT NULL,
                phone_number TEXT,
                who_has_it TEXT,
                photo_path TEXT,
                reported_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                status TEXT DEFAULT 'Active'
            )
        ''')
        conn.commit()
        conn.close()

# Ensure upload directory exists
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
init_db()

@app.route('/')
def index():
    conn = get_db_connection()
    items = conn.execute('SELECT * FROM items WHERE status = "Active"').fetchall()
    conn.close()

    lost_items = []
    found_items = []
    
    current_time = datetime.now()

    for item in items:
        # reported_date format from sqlite CURRENT_TIMESTAMP: 'YYYY-MM-DD HH:MM:SS'
        try:
            reported_date = datetime.strptime(item['reported_date'], '%Y-%m-%d %H:%M:%S')
        except ValueError:
            # Fallback if the timestamp format is different
            reported_date = datetime.strptime(item['reported_date'].split('.')[0], '%Y-%m-%d %H:%M:%S')

        days_passed = (current_time - reported_date).days
        action_required = days_passed > 30

        item_dict = dict(item)
        item_dict['days_passed'] = days_passed
        item_dict['action_required'] = action_required

        if item['report_type'] == 'Lost':
            lost_items.append(item_dict)
        elif item['report_type'] == 'Found':
            found_items.append(item_dict)

    return render_template('index.html', lost_items=lost_items, found_items=found_items)

@app.route('/submit', methods=['POST'])
def submit():
    report_type = request.form.get('report_type')
    category = request.form.get('category')
    location = request.form.get('location')
    description = request.form.get('description')
    phone_number = request.form.get('phone_number')
    who_has_it = request.form.get('who_has_it') if report_type == 'Found' else None

    # Server-side validation for required fields
    if report_type == 'Lost':
        if not description:
            flash('Description is required for lost items.', 'error')
            return redirect(url_for('index'))
        if not phone_number:
            flash('Phone number is required for lost items.', 'error')
            return redirect(url_for('index'))
    elif report_type == 'Found':
        if not location:
            flash('Location is required for found items.', 'error')
            return redirect(url_for('index'))
        if not who_has_it:
            flash('Please specify who currently has the item.', 'error')
            return redirect(url_for('index'))

    if phone_number and not re.match(r'^\+?[\d\s\-()]{7,20}$', phone_number):
        flash('Invalid phone number format.', 'error')
        return redirect(url_for('index'))

    photo_path = None
    if 'photo' in request.files:
        file = request.files['photo']
        if file and file.filename != '':
            if not allowed_file(file.filename):
                flash('Invalid photo format. Only PNG, JPG, JPEG, and GIF are allowed.', 'error')
                return redirect(url_for('index'))
            filename = secure_filename(f"{datetime.now().strftime('%Y%m%d%H%M%S')}_{file.filename}")
            file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
            photo_path = f"uploads/{filename}"

    conn = get_db_connection()
    conn.execute('''
        INSERT INTO items (report_type, category, location, description, phone_number, who_has_it, photo_path)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ''', (report_type, category, location, description, phone_number, who_has_it, photo_path))
    conn.commit()
    conn.close()

    flash('Item reported successfully!', 'success')
    return redirect(url_for('index'))

@app.route('/resolve/<int:item_id>', methods=['POST'])
def resolve(item_id):
    action = request.form.get('action') # 'resolve' or 'delete'
    conn = get_db_connection()
    if action == 'resolve':
        conn.execute('UPDATE items SET status = "Resolved" WHERE id = ?', (item_id,))
    elif action == 'delete':
        item = conn.execute('SELECT photo_path FROM items WHERE id = ?', (item_id,)).fetchone()
        if item and item['photo_path']:
            file_path = os.path.join('static', item['photo_path'])
            if os.path.exists(file_path):
                os.remove(file_path)
        conn.execute('DELETE FROM items WHERE id = ?', (item_id,))
    conn.commit()
    conn.close()
    
    flash('Item updated successfully.', 'success')
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True, port=5000)
